var searchData=
[
  ['address',['address',['../structOBNetIpConfig.html#a89cfcf57f564cb6f7a20b2a26284e11b',1,'OBNetIpConfig']]],
  ['args',['args',['../structob__error.html#a26d098478716ef96c7ed479dfb3eff58',1,'ob_error']]]
];
