var searchData=
[
  ['metadata',['metadata',['../classob_1_1VideoFrame.html#aefc4f6800518981d5bb2834644eae284',1,'ob::VideoFrame']]],
  ['metadatasize',['metadataSize',['../classob_1_1VideoFrame.html#a8e0e66c61a5de2160bbec24fd5b98e8e',1,'ob::VideoFrame']]]
];
