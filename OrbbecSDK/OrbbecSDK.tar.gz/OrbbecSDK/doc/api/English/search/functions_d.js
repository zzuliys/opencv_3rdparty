var searchData=
[
  ['querydevicelist',['queryDeviceList',['../classob_1_1Context.html#ac1dbaaaa2f6a4e53fb039e485d18267b',1,'ob::Context']]]
];
