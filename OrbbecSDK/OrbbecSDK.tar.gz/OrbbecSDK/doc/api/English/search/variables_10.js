var searchData=
[
  ['size',['size',['../structOBDataChunk.html#af80b0059d918467b6b58e56b798c8ad1',1,'OBDataChunk']]],
  ['status',['status',['../structob__error.html#afc2451cf30a6e060b284e38ec60c2993',1,'ob_error']]],
  ['step',['step',['../structOBIntPropertyRange.html#a01e6e87553be91eaff2ac559eb114f94',1,'OBIntPropertyRange::step()'],['../structOBFloatPropertyRange.html#ae67f00fcb8e7a103b749835a0e0cbaa5',1,'OBFloatPropertyRange::step()'],['../structOBBoolPropertyRange.html#ac3fa21c03a908853058b4ab33451fb22',1,'OBBoolPropertyRange::step()']]],
  ['syncmode',['syncMode',['../structOBDeviceSyncConfig.html#a19078aa83a64a13f659613811f27b152',1,'OBDeviceSyncConfig::syncMode()'],['../structob__multi__device__sync__config.html#a8cc39ed5db27676bdf5cffcb5ccbed67',1,'ob_multi_device_sync_config::syncMode()']]]
];
