var searchData=
[
  ['g',['g',['../structOBColorPoint.html#a23d807a8ea2590c6542c2bfde9590bcd',1,'OBColorPoint']]],
  ['gateway',['gateway',['../structOBNetIpConfig.html#a3aa1a811f515f6a5bdd03523f89d4181',1,'OBNetIpConfig']]]
];
