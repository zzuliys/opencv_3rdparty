var searchData=
[
  ['b',['b',['../structOBColorPoint.html#a479d6d154f5d673c41b3197ff708fd22',1,'OBColorPoint']]],
  ['baseline',['baseline',['../structBASELINE__CALIBRATION__PARAM.html#a94c00a31d7ff90eaaf9d84e4f1e95932',1,'BASELINE_CALIBRATION_PARAM']]]
];
