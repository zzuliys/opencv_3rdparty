var searchData=
[
  ['name',['name',['../classob_1_1DeviceInfo.html#a2f54ab5afea08b1ed24e0df363a22f9f',1,'ob::DeviceInfo::name()'],['../classob_1_1DeviceList.html#ad8e995e429946eccd954315b354107dd',1,'ob::DeviceList::name()']]]
];
