var searchData=
[
  ['checksum',['checksum',['../structOBDepthWorkMode.html#a3d7dbf9351ce403fcae1e502fcfc1d33',1,'OBDepthWorkMode']]],
  ['chipbottomtemp',['chipBottomTemp',['../structOBDeviceTemperature.html#a3054e79cde62f8c8083614daf62d6b47',1,'OBDeviceTemperature']]],
  ['chiptoptemp',['chipTopTemp',['../structOBDeviceTemperature.html#af75f06b38dcd78edc5fec267b8c02ac2',1,'OBDeviceTemperature']]],
  ['cmdversion',['cmdVersion',['../structOBDataBundle.html#a680a947cb52f7a64ec0aa17b4bfe2d9c',1,'OBDataBundle']]],
  ['colordelayus',['colorDelayUs',['../structob__multi__device__sync__config.html#aa5909e5e5238eb9c5cfe8261561c38fd',1,'ob_multi_device_sync_config']]],
  ['cputemp',['cpuTemp',['../structOBDeviceTemperature.html#afa6b196156fd9b4b85a33e332440bc6a',1,'OBDeviceTemperature']]],
  ['cur',['cur',['../structOBIntPropertyRange.html#acae2aaab07f2cc2a2842f1e602765a7b',1,'OBIntPropertyRange::cur()'],['../structOBFloatPropertyRange.html#a0196dc2692726aeafc9718f5988b1ec8',1,'OBFloatPropertyRange::cur()'],['../structOBBoolPropertyRange.html#a6aec56bfe29835e89fa5607e3bf04ce8',1,'OBBoolPropertyRange::cur()']]],
  ['cx',['cx',['../structOBCameraIntrinsic.html#a50b429aad5b3819aec089b154cea6297',1,'OBCameraIntrinsic']]],
  ['cy',['cy',['../structOBCameraIntrinsic.html#a6f6b987279f103e7843dc1fd9caa369f',1,'OBCameraIntrinsic']]]
];
