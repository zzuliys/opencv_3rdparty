var searchData=
[
  ['r',['r',['../structOBColorPoint.html#afe48bc5c44ced94fc3e9bde3653ba5fb',1,'OBColorPoint']]],
  ['rgbdistortion',['rgbDistortion',['../structOBCameraParam.html#a0629e0ee848fc0b6a1ded5ac64166235',1,'OBCameraParam::rgbDistortion()'],['../structOBCameraParam__V0.html#a8d49ffcb10562873b29c60864e512474',1,'OBCameraParam_V0::rgbDistortion()']]],
  ['rgbintrinsic',['rgbIntrinsic',['../structOBCameraParam.html#acc6d8df18c5216e8e1bd6188ed68d47e',1,'OBCameraParam::rgbIntrinsic()'],['../structOBCameraParam__V0.html#a9f9eeb405b3c19bc1c9422ae32474f7d',1,'OBCameraParam_V0::rgbIntrinsic()']]],
  ['rgbtemp',['rgbTemp',['../structOBDeviceTemperature.html#af3e639159fffb2171c01381db38527e8',1,'OBDeviceTemperature']]],
  ['rgbtriggersignalindelay',['rgbTriggerSignalInDelay',['../structOBDeviceSyncConfig.html#a004e403a03bc62458a6f7809d5463e51',1,'OBDeviceSyncConfig']]],
  ['rot',['rot',['../structOBD2CTransform.html#a9b8da8c82da9e03b92299e6816a963d1',1,'OBD2CTransform']]]
];
