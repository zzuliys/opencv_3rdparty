var searchData=
[
  ['accelframe',['AccelFrame',['../classob_1_1AccelFrame.html#a4a4959a6268a677788d4584a19f7d26c',1,'ob::AccelFrame::AccelFrame(Frame &amp;frame)'],['../classob_1_1AccelFrame.html#a0497ee5a617e3c1407e79051a99f26e0',1,'ob::AccelFrame::AccelFrame(std::unique_ptr&lt; FrameImpl &gt; impl)']]],
  ['accelstreamprofile',['AccelStreamProfile',['../classob_1_1AccelStreamProfile.html#ad1037c14505bce1a90145cdd9579889b',1,'ob::AccelStreamProfile::AccelStreamProfile(StreamProfile &amp;profile)'],['../classob_1_1AccelStreamProfile.html#aca8e4d3f1bb11e7a4923d8b9fd37186e',1,'ob::AccelStreamProfile::AccelStreamProfile(std::unique_ptr&lt; StreamProfileImpl &gt; impl)']]],
  ['activateauthorization',['activateAuthorization',['../classob_1_1Device.html#a2bec58d49565ad02b7951907fb71ee2c',1,'ob::Device']]],
  ['as',['as',['../classob_1_1Frame.html#ad469213f43249aabce4b96d746527a62',1,'ob::Frame::as()'],['../classob_1_1StreamProfile.html#a6dd7bd423b1b391e3c647944c1ad021a',1,'ob::StreamProfile::as()']]],
  ['asicname',['asicName',['../classob_1_1DeviceInfo.html#af524e81008d31f51a33513755d078938',1,'ob::DeviceInfo']]]
];
