var searchData=
[
  ['data',['data',['../structOBDataChunk.html#a259bca37ce7de4c8ccfb53d6dd9eef16',1,'OBDataChunk::data()'],['../structOBDataBundle.html#ac88e7834ff571269c27a4bf9f9b0b79f',1,'OBDataBundle::data()']]],
  ['datasize',['dataSize',['../structOBDataBundle.html#a894e264e761bfcea31c96e9d19b0876e',1,'OBDataBundle']]],
  ['def',['def',['../structOBIntPropertyRange.html#a1e805ffd6e3a0749bbbf96334673d260',1,'OBIntPropertyRange::def()'],['../structOBFloatPropertyRange.html#a999993d4ee54185981e537e9fb931018',1,'OBFloatPropertyRange::def()'],['../structOBBoolPropertyRange.html#a0172fa01e9d98f366a14648f19865699',1,'OBBoolPropertyRange::def()']]],
  ['depthdelayus',['depthDelayUs',['../structob__multi__device__sync__config.html#a0413ddb90e90b291e14544c38d88a697',1,'ob_multi_device_sync_config']]],
  ['depthdistortion',['depthDistortion',['../structOBCameraParam.html#ae6e904b125b297f70aeae248efb5fe38',1,'OBCameraParam::depthDistortion()'],['../structOBCameraParam__V0.html#a9c236538df64a0a19116c9ca19dbe456',1,'OBCameraParam_V0::depthDistortion()']]],
  ['depthintrinsic',['depthIntrinsic',['../structOBCameraParam.html#ae19c6de2bef4c15b282ea14614546629',1,'OBCameraParam::depthIntrinsic()'],['../structOBCameraParam__V0.html#ae123d678ab0873314da19778983ca28b',1,'OBCameraParam_V0::depthIntrinsic()']]],
  ['deviceid',['deviceId',['../structOBDeviceSyncConfig.html#a793d1603876f061fc3ab0c26131e73ff',1,'OBDeviceSyncConfig']]],
  ['devicetriggersignaloutdelay',['deviceTriggerSignalOutDelay',['../structOBDeviceSyncConfig.html#acd2b333bb455fc6c6a716e16ae6e8bba',1,'OBDeviceSyncConfig']]],
  ['devicetriggersignaloutpolarity',['deviceTriggerSignalOutPolarity',['../structOBDeviceSyncConfig.html#a5e36a59f45da629155068a69dc8d7959',1,'OBDeviceSyncConfig']]],
  ['dhcp',['dhcp',['../structOBNetIpConfig.html#a3de2c46f23cb239f849d0b3a3fabc337',1,'OBNetIpConfig']]],
  ['distortion',['distortion',['../structOBCalibrationParam.html#ab7bf5f50e9aa26ba9cd2710685bd5628',1,'OBCalibrationParam']]]
];
