var searchData=
[
  ['recorder',['Recorder',['../classob_1_1Device.html#a2950f414c752afb074d9849f834ae58e',1,'ob::Device::Recorder()'],['../classob_1_1Frame.html#a2950f414c752afb074d9849f834ae58e',1,'ob::Frame::Recorder()']]]
];
