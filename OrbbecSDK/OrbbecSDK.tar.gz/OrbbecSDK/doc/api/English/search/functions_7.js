var searchData=
[
  ['index',['index',['../classob_1_1Frame.html#a1001bd44f6b2a2eb0b4c4b7bb0f317f1',1,'ob::Frame']]],
  ['ipaddress',['ipAddress',['../classob_1_1DeviceInfo.html#a556966c9c65b4ed4484d985356a86c74',1,'ob::DeviceInfo::ipAddress()'],['../classob_1_1DeviceList.html#ae94682c089d204359c5928919d08b374',1,'ob::DeviceList::ipAddress()']]],
  ['irframe',['IRFrame',['../classob_1_1IRFrame.html#a3af02cbe76dccc9d54e037af23459f12',1,'ob::IRFrame::IRFrame(Frame &amp;frame)'],['../classob_1_1IRFrame.html#a76778af1a2dc19bbca6a3fe8b012a428',1,'ob::IRFrame::IRFrame(std::unique_ptr&lt; FrameImpl &gt; impl)'],['../classob_1_1FrameSet.html#abc6ba365ed4fb93721863b6f65c03c17',1,'ob::FrameSet::irFrame()']]],
  ['is',['is',['../classob_1_1Frame.html#ae6ce510d6e741d3f46ec34d475074b6f',1,'ob::Frame::is()'],['../classob_1_1StreamProfile.html#a7db61937ccf512a635e08a3aba3cc422',1,'ob::StreamProfile::is()']]],
  ['isglobaltimestampsupported',['isGlobalTimestampSupported',['../classob_1_1Device.html#adeb33fac92905821f2038f0464a6b31b',1,'ob::Device']]],
  ['ispropertysupported',['isPropertySupported',['../classob_1_1Device.html#a6401bf12c3eccd82891da15ebf2dd81c',1,'ob::Device']]]
];
