var searchData=
[
  ['getdatacallback',['GetDataCallback',['../Types_8hpp.html#ad61b52694f0b59f151b1a380d3db0876',1,'Types.hpp']]]
];
