var searchData=
[
  ['logcallback',['LogCallback',['../classob_1_1Context.html#aad80df0d99a8a939d58a476e00f7432f',1,'ob::Context']]]
];
