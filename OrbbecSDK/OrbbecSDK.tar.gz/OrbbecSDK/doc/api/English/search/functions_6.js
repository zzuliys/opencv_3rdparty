var searchData=
[
  ['hardwareversion',['hardwareVersion',['../classob_1_1DeviceInfo.html#a10909eb5fcd5992288fe259bd6789f11',1,'ob::DeviceInfo']]],
  ['height',['height',['../classob_1_1VideoFrame.html#a573adfe829fffa24f5c025804d157bee',1,'ob::VideoFrame::height()'],['../classob_1_1VideoStreamProfile.html#a4a0e412439217a8991129420c423b409',1,'ob::VideoStreamProfile::height()']]]
];
